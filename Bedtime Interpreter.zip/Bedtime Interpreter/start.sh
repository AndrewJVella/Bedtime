echo "Initializing..."
cd bin
rm *.bdti-
clear
java Main
echo "Closing..."
sleep 3
