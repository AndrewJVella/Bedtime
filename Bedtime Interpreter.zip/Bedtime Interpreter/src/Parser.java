import java.util.Arrays;


//Grammar

// Program ::= {Sentence}
// Sentence ::= Fragment \007 Printable
// Fragment ::= Value, Op 
// Value ::= {Word}
// Op ::= Alpha, Terminator
// Word ::= Alpha, Space
// Alpha ::= {Letter}
// Printable ::= ' " ' {Letter \007 Space} ' " '
// Space ::= ' '
// 
// Terminator ::= '.' \007 ';' \007 '?' \007 '!' \007 ','
// Letter ::= All printable letters and symbols that are not whitespace or listed above.

public class Parser {
	
	public static String parse(String source) {
		EOFcheck(source);
	
		
		return parseSentences(BoringCheck(getSentences(source)));
		
		
	}
	
	private static void EOFcheck(String s) {

		//count the number of " and if there is an odd number throw an EOF.		
		int c = 0;
		
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == 34) {
				c++; 
			}
		}

		

		if (c % 2 != 0) {
			Error.printError(ErrorType.EOF);
		}
	}
	
	private static String BoringCheck(String s) {
		
		 String[] S = s.split("\n");
		   
		   for (int i = 0; i < S.length; i++)
		   {
			   boringCheckOneSentence(S[i]);
		   }
		   
		return s;
	}
	
	private static String boringCheckOneSentence(String source) {
		
		String temp = source.toLowerCase();

		temp = temp.toLowerCase();
		temp = temp.replace("the", "");
		temp = temp.replace("\"", "");
		temp = temp.replace(".", "");
		temp = temp.replace(",", "");
		temp = temp.replace(";", "");
		temp = temp.replace("!", "");
		temp = temp.replace("?", "");
		temp = temp.replace('\007' + "", "");
		
		temp = temp.replace("\n", " ");
		String[] words = temp.split(" ");
		
		
		
		//remove two letter and less words
		
		String bunny = "";
		
		for (int i = 0; i < words.length; i++) {
			if (words[i].length() > 2) {
				bunny += (words[i] + "\n");
			}
		}
		
		//remove extraneous spaces
		bunny = bunny.replace(" ", "");
		
		words = bunny.split("\n"); //set words to a more efficient list
		
		if (words.length > 3) {
			Arrays.sort(words);
			
			int c = 0;
			for (int i = 1; i < words.length; i++) {
				if (words[i].equals(words[i-1])) {
					c++;
				}
				
				if (!words[i].equals(words[i-1])) {
					c = 0;
				}
			}
			
			if (c >= 3) {
				Error.printError(ErrorType.Boring); //then there are four identical words in the sentence
			}
				
		}
				
		return source;
	}
	//each sentence gets its own line in the output string. (Yes, a comma ends a sentence)
	private static String getSentences(String source) { //fetch
		  source = source.replace("...", "\007");
		  source = source.replace("..!", "\007!");
		  source = source.replace("..?", "\007?");
		  
		//source.replace('\n', ' '); //replace all newlines with a space 
		boolean isAPrintable = false;
		String sent = "";
		String output = "";
		
		for (int i = 0; i < source.length(); i++) { 
			sent += source.charAt(i);
			
			//Printable case
			if (source.charAt(i) == '"') {
				isAPrintable = !isAPrintable;
				
				if(!isAPrintable) {
					sent += "\n";
					output += sent;
					sent = "";
					
				}}
			
			//Fragment case
			if (!isAPrintable) {
				
				if (source.charAt(i) == '.' || source.charAt(i) == ',' || source.charAt(i) == ';' || source.charAt(i) == '?' || source.charAt(i) == '!' || source.charAt(i) == ':') {
					sent += "\n";
					output += sent;
					sent = "";
					
				}}
          }
	
		return output;
	}
	
   public static String parseSentences(String source) { //get the length of each word in a sentence and translate to nondescript source  
	   //Essentially, each sentence is parsed backwards (right to left) so the operation comes first, then the value (sentences can end with a comma)
	   //Source is parsed from top to bottom, right to left.
	   //A printable is parsed as a series of operations with the op code 1, followed by an ASCII char as an integer value
	   //Terminators in bedtime that are not between two and twelve chars in length inclusive are set to op code 13, a no op.
	   String out = "";
	   String[] S = source.split("\n");

	   
	   for (int i = 0; i < S.length; i++)
	   {
		 
		   out += parseSentence(S[i]);
	   }
		
	   return out;
	}
   
   //these functions are called by the one above, outputs from each call are concatenated together.
   
   private static String parseSentence(String s) {
	   
	   
	   if (s.contains("\"")) { 
		  return  parsePrintable(s);
		   
	   }
	   
	   else {
		return   parseFragment(s);
	   }
	   
   }
   
  private static String parseFragment(String s) {
	  
	 s = s.replace("(", "");
	 s = s.replace(")", "");
	 s = s.replace("\t", "");

  
	  boolean invertValueSign = false;
	  String value = "";
	  String temp = "";
	  int OpCode = -1;
	  int i = 0;
	  
	  s = ' ' + s;
	  
	  i = s.length() - 1;
	  
	  //check for invert
	  if (s.charAt(i) == '?') {
		  invertValueSign = true;
	  }
	  
	  //get opcode
	  while (s.charAt(i) != ' ' && i > 0) {
		  i--;
		  OpCode++;
		  
		  if (s.charAt(i) == '\007') {
			  OpCode = 0;
			  while(s.charAt(i) != ' ' && i > 0)  {
					i--;
					
				}
		  }
	  }
	  
	  while (i > 0) {
		  i--;
		  
		 
		  if (s.charAt(i) == ' ') {
			  value = temp.length() + value;
			  temp = "";
			  
		  }
		  
		  if (s.charAt(i) == '\007') 
		  {	
			temp = "";
			
			while(s.charAt(i) != ' ' && i > 0)  {
				i--;
				
			}
			value += 0;
		
			
		  
		  }
		  
		  
		  temp += s.charAt(i);
		  
		 
		  
		  temp = temp.replace(" ", "");
		  temp = temp.replace("\007", "");
	  }
	  
	  
	  
	  
	  if (OpCode < 0 || OpCode > 12) {
		  OpCode = 13;
	  }
	  
	 
	  

	  
	  if (isInt(value) && !(value == "" || value == "-")) {
	  value = Integer.toString(Integer.parseInt(value) % 256); //allows for the construction of longer sentences that are programmatically useful.
	  }
	  
	  if (invertValueSign) {
		  value = "-" + value;
	  }
	  
	  if (value.equals("-") || value.equals("-0")) {
		  value = "0";
	  }
	  
	  return Integer.toString(OpCode) + " " + value + "\n";
	  
	  
	  
	   
   }
  private static String parsePrintable(String s) {
	   
	  int c = 0;

	  while (s.charAt(c) != '\"') {
			  c++;
	  }
	  
	
	  	
	  
	  
	  
	   s = s.replace('\"' + "", "");
	   s = s.replace("''", "\""); //allows for the printing of double quotes
		
		String out = "";
		
		int foo = 0; 
		for (int i = c; i < s.length(); i++) {
			if (s.charAt(i) < 10) {
				foo = 4;
			}
			else {
				foo = 0;
			}
			out += "1 " + Integer.toString(s.charAt(i) + foo) + "\n";
			
			
		}
		return out;
	  		
  }
  

  public static boolean isInt(String s) {
	  try {
		  Integer.parseInt(s);
		  return true;
	  }
	  catch (NumberFormatException n) {
		  return false;
	  }
  }

}
