import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Reader {
	
	
	  public String read(String p) throws FileNotFoundException {
		  String s = literalReader(p);
		  
		  return s;
	  }
		  public String literalReader(String p) throws FileNotFoundException  {
			   
			     
		      String output = "";
		      File f = new File(p);
		      Scanner myReader = new Scanner(f);
		      
		      while (myReader.hasNextLine()) {
		        String foo  = myReader.nextLine();
		        
		        
		        
		        output += foo + "\n";
		        }
		      
		      myReader.close();
		      return output;
		      
		  }
		  
	
		  
		public String getExtension(String f) {
			//split refuses to cooperate
			
			String foo = "";
			
			for (int i = f.length() -1; i > -1; i--) {
				
				foo += f.charAt(i);
				if (f.charAt(i) == '.') {
					break;
					//I used break, get over it.
				}}
			String exten = "";
			
			for (int i = foo.length() -1; i > -1; i--) {
				exten += foo.charAt(i);
			}
			
			if (!exten.contains(".")) {
				exten = ".bdti";
			}	
			
			else {
				exten = "";
			}
			
			return exten;		
		}

		public String read(File f) throws FileNotFoundException {

			return read(f.getName());
		}
		

		
		
		 
		
	  

}
