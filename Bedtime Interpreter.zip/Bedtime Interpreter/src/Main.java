import java.io.FileNotFoundException;
import java.util.Scanner;


//.bdti extension
public class Main {
	

	static Scanner scan = new Scanner(System.in);
	static Reader r = new Reader();
	static boolean debug = false;

	//defines various commands. They must all be unique
	final static String commHelp = "-help";
	final static String commShell = "-shell";
	final static String commNdsc = "-ndsc";
	final static String commDebug = "-debug";
	final static String commWord = "-word";
	
	public static void run (String s) {

		//needs to go through preprocessor first
		if (debug) {
			System.out.println("Debug Console:\n");
			System.out.println(Parser.parse(s));
			System.out.println("\nExecution:\n");
		}
	
		Ndsc.Interpret(Parser.parse(s));	
	}
	
	public static void main(String args[]) {
		
	//	for (int i = 0; i < args.length; i++) {
		//	System.out.println( "'" + args[i] + "'");
		//}
		if ((args.length > 1 && args[1].equals("-shell"))) {

		//the -shell flag indicates this is a subprocess and needs to close.
		//System.out.println("-shell flag active.");
		runner(args[0]);
		end(); 


	}

	else{
		
		System.out.println("Welcome to the Bedtime Interpreter.\n\nType '" + commDebug + "' to enter debug mode.\nType '" + commHelp + "' to read the Bedtime help doc.\nType '" + commNdsc + "' to read the Nondescript help doc\nType '" + commShell + "' to open the shell.\nType '" + commWord + "' to start the word generator.\nYou can also give command line arguments.");
		System.out.println("\n\nThe dictionary is pulled from various sources:\nhttps://www.dictionary.com/\nhttps://github.com/PixelatedStarfish/Keybasket/tree/master/Keybasket%20v%201_4\nhttps://en.wikibooks.org/wiki/Scrabble/Two_Letter_Words\nhttp://www.yougowords.com/\n\n");
	}

		//run the file given in the command line, if no arg is given, ask for one!
		String n = "";
		if (args.length == 0) {
			System.out.println("No arguments were given, please give a program file or command.\n> ");
			n = scan.nextLine(); }
		else {
			n = args[0];
		}

		
		if (n.equals(commHelp)) {
			clearScreen();
			Help.HelpDoc();
			end();
		}
		
		if (n.equals(commNdsc)) {
			clearScreen();
			Help.nHelpDoc();
			end();
		}

		if (n.equals(commWord)) {
			clearScreen();
			Words.wordSubProgram();
			end();
		}


			if (n.equals(commShell)) {
			clearScreen();
			Shell.shell();

			end();
		}
		
		else {
			if (n.equals(commDebug)) {
				debug = true;
				System.out.println("Debugger on.\nPlease give a source file.");
				n = scan.nextLine();
				}
			
			runner(n);
			}}


	public static void runner(String n) {
		try {	
				String s = r.read(n);
				System.out.print("\n*Running " + n + "*" + "\n");
			    run(Prep.prep(s));	
			    
			} catch (FileNotFoundException e) {
				System.out.println("Bedtime Story \"" + n + "\" Not Found.");
				
			}
	}
	

	
	 
	public static void end() {
		System.out.print("\n\n*End of Program.*");
		System.exit(0);
	}

public static void clearScreen() {
	System.out.print("\033[H\033[2J");
	return;

}}

