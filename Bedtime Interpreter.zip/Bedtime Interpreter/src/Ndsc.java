import java.util.ArrayList;


public class Ndsc {

	static int pc = 0;
	static ArrayList<int[]> Labels = new ArrayList<int[]>();
	static Stack S = new Stack();

	

public static void Interpret(String s) {	
	
	try {	
		 
		execute(decode(fetch(s)));
	}
	
	catch(OutOfMemoryError so) {
		Error.printError(ErrorType.Stack_Overflow);
	
   }

	catch(Exception e) {
		Error.printError(ErrorType.Generic);
		//e.printStackTrace();
	}
}
	
	public static  String[][] fetch(String s) {
		s = s.replace("\r", "");
		
		String lines[] = s.split("\n");
		String[][] commands = new String[lines.length][2];
		
		for (int i = 0; i < lines.length; i++) {
			commands[i] = lines[i].split(" ");
		}
		
		return commands;
	}
	
	static int[][] decode(String[][] c) {
		
		//get commands
		
		int[][] commands = new int[c.length][2];
		
		for (int i = 0; i < commands.length; i++) {
			
			//System.out.println(c[i][0] + " " + c[i][1]);
			
			if (!(c[i][0].equals("#")))
			{ commands[i][0] = Integer.parseInt(c[i][0]); }
			
			else {
				commands [i][0] = -1; //a comment
			}
			
			
			try {
				
				parseAsInt(c[i], commands[i]);
			
				}
				
			 catch (NumberFormatException nfe) {
				commands[i][1] = (int) c[i][1].charAt(0);
				//System.out.print("case 5\n");
				
			}
			
		}
		
		
		//get labels
		for (int i = 0; i < commands.length; i++) {
			//Adds all labels
			int[] l = new int[2];
			if (commands[i][0] == 6) { //a label
				l[0] = commands[i][1];
				l[1] = i;
				Labels.add(l);
			}}
		return commands;
	}
	
	
	private static int[] parseAsInt(String[] c, int[] command) throws NumberFormatException {
		if (c.length > 1 && c[1].length() == 1) {
			
			command[1] = Integer.parseInt(c[1]); 
			//System.out.print("case 1\n");
			return command;
			}
	
		if(c.length > 1 && c[1].length() > 1 && c[1].charAt(c[1].length() -1) == 'c') {
			
			if (!c[1].contains("-")) {
			command[1] = (int) c[1].charAt(c.length -2);
			//System.out.print("case 2a\n");
			return command; }
			
			else {
				command[1] = (int) c[1].charAt(c.length -2) *-1;
				//System.out.print("case 2b\n");
				return command;
			}
	
		}
	
		if(c.length < 1) {
			command[1] = 0;
			//System.out.print("case 3\n");
			return command;
		}
		
		//System.out.print("case 4\n");
		if (c.length > 1) {
			command[1] = Integer.parseInt(c[1]);
		}
		return command;

	
	}
	
	private static void execute(int[][] c) {
		pc = 0;

		while (pc < c.length) {
			//System.out.println(pc);
			executor(c);
			pc++;
			
		}}
	
	private static void executor(int[][] c) {

		switch (c[pc][0]) {
		
		//Good
		case -1: {
			return;
			
		}
		
        //Good!
		 case 0: {
			 System.out.print(S.peek());
				return;
		
		}
		 
	        //Good!
		 case 1: {
				System.out.print((char) c[pc][1]);
				return;
			}
		 
	
		  //Good!
	        case 2: {
	            
				System.out.print((char) S.peek());
	             return; 
	       
			}
	        
	      //Good!
			case 3: {
 	            
 				S.pop();
 	             return; 
 	       
 			}
	        
	     //Good!
	     	case 4: {
	     	             
	     		S.push(c[pc][1]);
	     		return; 
	     	     
	     			}
	     			
	     	
	        
	   	 //Good!
			case 5: {
	            
				S.plus(c[pc][1]);
				return;
	        
			}
			
			//Good!
			 case 6: {
					//lbl
				 return;
				}
	     
	       
		     //Good!
		 case 7: {
				Goto(c[pc][1]);
				return;
			}
		 
	    
			
	     //Good!
		 case 8: {
			 int q = S.peek();
            
			 if (q == 0) {
	          Goto(c[pc][1]); }
        return; }
		
	     //Good!
		 case 9: {
            
			 
		
			//integer
			 if (c[pc][1] == 1) {
				 
				System.out.print("\n-Give Input to Continue-\n");

				String s= Main.scan.nextLine(); //reads string
			        int   inp = Integer.parseInt(s);
				 
				 if (inp < 0 || inp > 255) {
					 end(4);
				 }
				 S.push(inp);
				 return;
			 
			 }
			 
			 //char array
			 if (c[pc][1] == 2) {
				 
					System.out.print("\n-Give Input to Continue-\n");

					String s= Main.scan.nextLine(); //reads string
				        
					for (int i = 0; i < s.length(); i++) {
						S.push((int) s.charAt(i));
					}
					return;
					 

					 }
			 
			 //char
			 else {
				 
					System.out.print("\n-Give Input to Continue-\n");

					String s= Main.scan.nextLine(); //reads string
				        char   inp = s.charAt(0);
					 
					 
					 S.push((int) inp);
					 return;
					 }
			 
		}
     
		//Good!
        case 10: {
            
			S.dup();
             return; 
       
		}
        
        //Good!
        case 11: {
            
			S.shuffle();
             return; 
       
		}
        
       
        //Good!
        case 12: {
            
			end(-1);
             return; 
       
		}
        //Good!
        case 13: {
            
        	try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				
				end(0);
			}
              return; 
        
 		}
         
        
        default: {
        	end(1);
        }
		
		
	}}  
	
	
	public static void end(int i) {
		
		
		if ( i == 0 ) {
			System.err.println("\nError. (" + i + ")");
			
		}
		
		if ( i == 1 ) {
			System.err.println("\nUndefined Op. (" + i + ")");
			
		}
		
		
		if ( i == 2 ) {
			System.err.println("\nStack Access Error. (" + i + ")");
			
		}
		
		if ( i == 3 ) {
			System.err.println("\nSyntax Error. (" + i + ")");
			
		}
		
		if ( i == 4 ) {
			System.err.println("\nBad Input. (" + i + ")");
			
		}

		
		System.out.println("\nEnd of Program.");

		if ( i < 0 ) {
		    System.exit(0); }
		if ( i > -1 ) {
		    System.exit(1); }
}
	 public static void Goto(int id) {
			//System.out.println("\ngoto");

		

			 
			 for (int i = 0; i < Labels.size(); i++) {
				 if (Labels.get(i)[0] == id) {
					 pc = Labels.get(i)[1];
					 
					// System.out.println(pc + " = "  + Labels.get(i)[1]);

					 return; }}
			 }}
