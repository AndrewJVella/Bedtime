import java.util.ArrayList;



public class Stack {
	
 	ArrayList<Integer> S = new ArrayList<Integer>();
 	
 	public Stack() {
 		
 	}
 	
 	public void plus(int p) {
 		
 		
 		
 		S.set(S.size() - 1, S.get(S.size() - 1) + p);
 	}
 	
   public int peek() {
	   
	   try {
 		
 		return S.get(S.size() - 1);
	   }
	   
	   catch (Exception e) {
		   Error.printError(ErrorType.Empty_Stack);
	   }
	return 0;

   }
   
   public int peekToo() {
	   
	   try {
		
 		return S.get(S.size() - 2);
	   }
	   
	   catch (Exception e) {
		   Error.printError(ErrorType.Empty_Stack);
	   }
	return 0;
 	}
 	
 	
 	public void dup() {
 		S.add(peek());
 	}
 	
 	public void push(int p) {
 		
 		S.add(p);
 	}
 	

 	
 
 	
 	public void pop() {
 		try {
 		S.remove(S.size() - 1);
 		}
 		
 	   catch (Exception e) {
		   Error.printError(ErrorType.Empty_Stack);
	   }
 	}
 	
 	public boolean isEmpty() {

 		return S.size() == 0;
 	}
	
 	public void empty() {

		S = new ArrayList<Integer>();
 	}
 	
 	public void printS() {

		for (int i = 0; i < S.size(); i++) {
			System.out.print(S.get(i) + "::");
		}
		System.out.println("length: " + S.size());
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 	}
	
 	public void shuffle() {
 		
 		try {
 	 	ArrayList<Integer> Shuffled = new ArrayList<Integer>();
 	 	
 	 	
 	 	while (S.size() > 0) {
 	 		double i = (Math.random() * (S.size()));
 	 		//System.out.println(i);
 	 		Shuffled.add(S.get((int) i));
 	 		S.remove((int) i);
 	 		//printS();
 	 	}

 	 	S = Shuffled;
 		
		
	} 
 		
 	   catch (Exception e) {
		   Error.printError(ErrorType.Empty_Stack);
	   }}
	


}