
public class Error {
	
	public static void printError(ErrorType e) {
		
		if (e == ErrorType.Boring) {
			
			System.err.println("\n*Your young listener critiques: \"This story is boring. Tell me another one!\"");
		}
		
		if (e == ErrorType.Generic) {
			
			System.err.println("\n*Your young listener critiques: \"I don't get it! What's going on? I want another story! Please?\"");
	
		}
		
	    if (e == ErrorType.Empty_Stack) {
			
			System.err.println("\n*Your young listener critiques: \"Can I have some water? My bottle is empty. Please?\"");
	
		}
		
		if (e == ErrorType.EOF) {
			
			System.err.println("\n*Your young listener critiques: \"Aw, the story can't be over yet! More please?\"");
	
		}
		
		
		if (e == ErrorType.Stack_Overflow) {
			
			System.err.println("\n*Your young listener is distracted: \"Oops!\" Their water bottle overflows onto the floor.");
	
		}
		
		Main.end();
		
	}

}
