import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;



public class Shell {
	public static Scanner scan = new Scanner(System.in);

	 public static void printLines(String cmd, InputStream ins) throws Exception {
        String line = null;
        BufferedReader in = new BufferedReader(
            new InputStreamReader(ins));
        while ((line = in.readLine()) != null) {
            System.out.println(line);
        }
      }

//Fixed this, but running throws an error
     public static String getMultiLineInput() {

     		String line = "\n";
     		String output = "";
  
     	    while (!line.isEmpty()) {

     	    	line = scan.nextLine();
            	output += line + "\n"; }
 
        return output;
    }
 



     public static void WriteToFile(String fileName, String content) 

     throws IOException {
     
      FileWriter riter = new FileWriter(fileName);
      riter.write(content);
      riter.flush();
      riter.close();
    }

      //rather than directly passing code to main, write it to a temp file and pass that to main
      public static void WriteAndRunTempFile(String s) throws IOException, Exception { 
      	File f = File.createTempFile("Bedtime_Story_",".bdti-"); //why the hyphen, for a second delete function 
      	System.out.println("Created " + f.getName());
      	WriteToFile(f.getName(), s);
      	//runProcess("java Main " + f.getName() + " -shell", f); //this flag indicates the shell is calling this process
      	

      	System.out.println(f.delete()); //despite all evidence to the contrary this actually works when WriteToFile and runprocess get commented out. Something is not closing properly FIXME

      }

	   //runs a shell command
	   public static void runProcess(String command, File f) throws Exception {
        Process pro = Runtime.getRuntime().exec(command);
        printLines("", pro.getInputStream());
        System.out.println("\n====");
       printLines(command + " stderr:", pro.getErrorStream());
        pro.waitFor();
        System.out.println(command + " exitValue() " + pro.exitValue());
        

        //System.out.println(f.delete());
      }
	public static void shell() {

	try {

		while(true) {
			String n = "";
			System.out.println("Welcome to the Bedtime Shell. Push enter to write a script here.\n> ");
			String s = getMultiLineInput();
			WriteAndRunTempFile(s);
		
	

			//quit or continue
			System.out.println("Push enter to continue, or type 'q' to quit\n> ");
			n = scan.nextLine();

			if (n.equals("q")) {
				System.out.println("\nClosing the shell. Goodbye.\n");
				break; //OOooOOOoooOOo a break!
			}}

		}
		catch (Exception e) {

			System.out.println("Error:\n\n");
			e.printStackTrace();
		}



		}}



//Runtime Env 
//https://www.digitalocean.com/community/tutorials/compile-run-java-program-another-java-program
