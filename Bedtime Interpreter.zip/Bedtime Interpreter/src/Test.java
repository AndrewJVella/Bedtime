


public class Test {
	
	//Test with the debugger on. Some results in compilation.

	//General
	String HelloWorld = "\"Hello World!\""; //PASSED
	String TruthMachine = "Charlie's! What could've ended? Forgives, a forget. Love spiritual O! A teacher. Bowser, four ghosties A."; //PASSED
	String RandomNumber = "A ball. My ball. The ball. That ball. Shiny ball. Dragon ball! Shenron rise! Immortality! ...Mine!"; //PASSED
	String Comment =  "(I AM A COMMENT) Mi(WOW)ne!"; //PASSED
	String tabInFrag = "\tFo\tur."; //Should compile to 4 in the debug console, ignoring the tabs. //PASSED 
	
	//Print Tests
	String FragmentAndPrint = "Not a Fake! \"Print this!\" How mysterious!";  //PASSED
	String BadFragment = "This fragment \"is incomplete.\""; //PASSED
	String doubleQuotePrint = "\"''\""; //prints a double quote //PASSED
	String Qprint = "\"?\""; //prints a question mark //PASSED
	String printTabandNewline = "\"\taaa\nssss\""; //PASSED
	String notComment = "\"(NOT A COMMENT)\""; //PASSED
	
	//noOp tests
	String noOp = "This is a no op test, prestidigitation."; //PASSED
	String noOp2 = "...";

	//Zero op tests (Should produce Empty stack error)
	String z1 = "."; //PASSED
	String z2 = "!"; //PASSED
	String z3 = "..!"; //PASSED
	
	//"Negative" zero (should also produce 0 or -0)
	String nz1 = "?"; //PASSED
	String nz2 = "..?"; //PASSED
	
	//Error Tests
	String EOF = "\"End of file error should be thrown here."; //PASSED
	String Boring = "Gosh, this is very very very very boring."; //PASSED
	String notBoring = "\"this is very very very boring.\""; //PASSED
	String notBoring2 = "ab ab ab ab the the the the"; //PASSED
	String Generic = "Gnric."; //PASSED
	String Overflow = "One Hundred Eighty. Thirty Four. One Hundred Seventy."; //PASSED
	
	//Mod Tests
	String _0_255 = "Hi sweet doggy ."; //Debug: 0 255  //PASSED
	String _0_0 = "Hi sweet doggie ."; //Debug: 0 0 //PASSED
	String n0_255 = "Hi sweet doggy ?"; //Debug: 0 -255 //PASSED
	String n0_0 = "Hi sweet doggie ?"; //Debug: 0 0 //PASSED

}
