
public enum ErrorType {
	Boring, Generic, Empty_Stack, EOF, Stack_Overflow
	

}

