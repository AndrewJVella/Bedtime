
//This is the preprocessor
	//preserves newlines and tabs in printables (Note beep is elipsis now, not |. newlines in print can be /006. Tab in print can be /005)
	//Preserves parens in printables
	//removes tabs outside of quotes
 	//removes comments
	
public class Prep {

	  private static String commentRemove(String s) {
		  String o = "";
		  boolean com = false;
		  boolean pri = false;
		  
		  
		  
		  for (int i = 0; i < s.length(); i++) {
			  if (s.charAt(i) == '(' ) {
				 if (!pri) {
				  com = true; }
			  }
			  
			  if (s.charAt(i) == ')' ) {
				 if (!pri) {
				  com = false;
				 }
			  }
			  
			  if (s.charAt(i) == '\"' ) {
				  pri = !pri;
			  }
			  
			 
			  
			  if (!com) {
				  o += s.charAt(i);
			  }}
		  
	
		  
	//parens are removed by parsefragment() as needed, so are tabs
		return o;
	  }
	  
	private static String subWhiteSpace(String s) {
		char[] charArray = new char[s.length()];
		
		for (int i = 0; i < charArray.length; i++) {
			charArray[i] = s.charAt(i);
		}
		boolean pri = false;
		
		for (int i = 0; i < charArray.length; i++) {
			if (charArray[i] == '\"' ) {
				  pri = !pri;
			  }
			
			if (charArray[i] == '\t'  && pri) {
				  charArray[i] = '\005';
			  }
			
			if (charArray[i] == '\n'  && pri) {
				  charArray[i] = '\006';
			  }
			
		}
		  
		String out = "";
		
		for (int i = 0; i < charArray.length; i++) {
			out += charArray[i];
		}
		
		out = out.replace("\t", "");
		return out;
			
		}
	
	public static String prep(String s) {
		s = subWhiteSpace(s);
		s = commentRemove(s);
		return s;
		
	}
}
